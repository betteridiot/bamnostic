from bamnostic.core import AlignmentFile, AlignedSegment

import pkg_resources
example_bam = pkg_resources.resource_filename('bamnostic', 'data/') + 'example.bam'